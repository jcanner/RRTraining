#' RRTraining
#'
#' A package about making a package connected to GitHub
#'
#'
#' @docType package
#' @name RRTraining
NULL